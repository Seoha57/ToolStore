<?php
/**
 * DB configuration variables
 */
 define("DB_HOST", "localhost");
 define("DB_USER", "seoha57");
 define("DB_PASSWORD","tjdgkr12!");
 define("DB_DATABASE","seoha57");
?>